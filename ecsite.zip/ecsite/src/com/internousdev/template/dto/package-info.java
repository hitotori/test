/**
 * 
 */
/**
 * @author internousdev
 *
 */
package com.internousdev.template.dto;