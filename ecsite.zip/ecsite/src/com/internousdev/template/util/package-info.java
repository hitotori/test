/**
 * 
 */
/**
 * @author internousdev
 *
 */
package com.internousdev.template.util;