package com.internousdev.template.action;

public class ItemListDeleteCompleteAction {

}
