package com.internousdev.template.action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.internousdev.template.dto.BuyItemDTO;
//import com.internousdev.template.dao.BuyItemCompleteDAO;
import com.opensymphony.xwork2.ActionSupport;

public class BuyItemConfirmAction extends ActionSupport implements SessionAware{

	public Map<String,Object>session;
	private ArrayList<BuyItemDTO> selectList=new ArrayList<BuyItemDTO>();
	private String pay;
	private String payment;


	//	private BuyItemCompleteDAO bicdao=new BuyItemCompleteDAO();
	@SuppressWarnings("unchecked")
	public String execute() throws SQLException{
		selectList=(ArrayList<BuyItemDTO>)session.get("selectList");
		BuyItemDTO bidto=new BuyItemDTO();
		for(BuyItemDTO dto:selectList){
			if(pay.equals("1")){
				payment="現金払い";
				bidto.setPay("payment");
				selectList.add(bidto);
			}else{
				payment="クレジットカード";
				bidto.setPay("payment");
				selectList.add(bidto);
			}
		}
//		bicdao.buyItemInfo(session.get("id").toString(),
//				           session.get("login_user_id").toString(),
//				           session.get("buyItem_price").toString(),
//				           session.get("count").toString(),
//				           session.get("pay").toString());

		String result =SUCCESS;
		return result;
	}

	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public ArrayList<BuyItemDTO> getSelectList() {
		return selectList;
	}
	public void setSelectList(ArrayList<BuyItemDTO> selectList) {
		this.selectList = selectList;
	}
	public String getPay() {
		return pay;
	}
	public void setPay(String pay) {
		this.pay = pay;
	}
	public Map<String,Object>session(){
		return session;
	}
	@Override
	public void setSession(Map<String,Object>session){
		this.session=session;
	}

}
