package com.internousdev.template.action;

import com.opensymphony.xwork2.ActionSupport;

public class ManagerCreateAction extends ActionSupport{
	public String execute(){
		return SUCCESS;
	}

}
