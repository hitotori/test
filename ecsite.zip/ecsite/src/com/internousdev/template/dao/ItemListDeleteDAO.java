package com.internousdev.template.dao;

public class ItemListDeleteDAO {

}
